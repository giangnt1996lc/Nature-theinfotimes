export const CMS_NAME = 'The Info Times'
export const CMS_URL = 'https://theinfotimes.com'
export const REDIRECT_ENABLE = true
export const HOME_OG_IMAGE_URL = ''